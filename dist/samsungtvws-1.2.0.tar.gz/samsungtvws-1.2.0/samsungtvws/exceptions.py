class ConnectionFailure(Exception):
    """Error during connection."""
    pass